import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sharepoint_monitor/main.dart';

void main() {
  testWidgets('Ekran aplikacji pokazuje ustawienia i historię', (tester) async {
    await tester.pumpWidget(const MaterialApp(home: MonitorHome()));
    expect(find.text('Historia zmian'), findsOneWidget);
    expect(find.text('Odśwież'), findsOneWidget);
    expect(find.text('Klucz API'), findsOneWidget);
  });
}
