import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(const SharePointMonitor());

class SharePointMonitor extends StatelessWidget {
  const SharePointMonitor({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'SharePoint Monitor',
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: const Color(0xFF2463EB)),
    home: const MonitorHome(),
  );
}

class MonitorHome extends StatefulWidget {
  const MonitorHome({super.key});
  @override
  State<MonitorHome> createState() => _MonitorHomeState();
}

class _MonitorHomeState extends State<MonitorHome> {
  final _storage = const FlutterSecureStorage();
  final _server = TextEditingController();
  final _key = TextEditingController();
  bool _busy = false;
  String _notice = 'Wprowadź adres swojego serwera monitorującego.';
  Map<String, dynamic> _status = {};
  List<Map<String, dynamic>> _changes = [];

  @override
  void initState() {
    super.initState();
    _restore();
  }

  Future<void> _restore() async {
    try {
      _server.text = await _storage.read(key: 'server') ?? '';
      _key.text = await _storage.read(key: 'api_key') ?? '';
      if (mounted && _server.text.isNotEmpty && _key.text.isNotEmpty) {
        await _refresh();
      }
    } catch (e) {
      if (mounted) setState(() => _notice = 'Nie udało się odczytać ustawień: $e');
    }
  }

  Future<dynamic> _request(String path, {bool post = false}) async {
    final raw = _server.text.trim();
    final base = Uri.tryParse(raw);
    if (base == null || base.scheme != 'https' || base.host.isEmpty || base.userInfo.isNotEmpty || base.query.isNotEmpty || base.fragment.isNotEmpty) {
      throw const FormatException('Podaj pełny adres HTTPS serwera.');
    }
    if (_key.text.trim().isEmpty) throw const FormatException('Podaj klucz API.');
    final prefix = raw.endsWith('/') ? raw.substring(0, raw.length - 1) : raw;
    final url = Uri.parse('$prefix$path');
    final headers = {'X-API-Key': _key.text.trim()};
    final response = await (post
      ? http.post(url, headers: headers).timeout(const Duration(seconds: 25))
      : http.get(url, headers: headers).timeout(const Duration(seconds: 25)));
    if (response.statusCode != 200) {
      throw Exception('Serwer zwrócił HTTP ${response.statusCode}');
    }
    return jsonDecode(utf8.decode(response.bodyBytes));
  }

  Future<void> _refresh({bool scan = false}) async {
    if (_busy) return;
    setState(() { _busy = true; _notice = 'Łączenie z serwerem…'; });
    try {
      await _storage.write(key: 'server', value: _server.text.trim());
      await _storage.write(key: 'api_key', value: _key.text.trim());
      if (scan) await _request('/scan', post: true);
      final status = Map<String, dynamic>.from(await _request('/status') as Map);
      final raw = await _request('/changes') as List;
      final changes = raw.map((item) => Map<String, dynamic>.from(item as Map)).toList();
      if (!mounted) return;
      setState(() {
        _status = status;
        _changes = changes;
        final error = status['last_error']?.toString() ?? '';
        _notice = error.isEmpty ? 'Dane pobrane pomyślnie' : 'Ostatni błąd skanowania: $error';
      });
    } catch (e) {
      if (mounted) setState(() => _notice = 'Błąd połączenia: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  void dispose() {
    _server.dispose();
    _key.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('SharePoint Monitor')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('BOK / Technologie', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('Monitor zmian w plikach dostępnych przez autoryzowany serwer.'),
      const SizedBox(height: 20),
      TextField(controller: _server, keyboardType: TextInputType.url, autocorrect: false,
        decoration: const InputDecoration(labelText: 'Adres serwera HTTPS', hintText: 'https://monitor.example.com', border: OutlineInputBorder())),
      const SizedBox(height: 12),
      TextField(controller: _key, obscureText: true, enableSuggestions: false, autocorrect: false,
        decoration: const InputDecoration(labelText: 'Klucz API', border: OutlineInputBorder())),
      const SizedBox(height: 12),
      Wrap(spacing: 8, runSpacing: 8, children: [
        FilledButton.icon(onPressed: _busy ? null : () => _refresh(), icon: const Icon(Icons.refresh), label: const Text('Odśwież')),
        OutlinedButton.icon(onPressed: _busy ? null : () => _refresh(scan: true), icon: const Icon(Icons.manage_search), label: const Text('Skanuj teraz')),
        TextButton.icon(onPressed: () async {
          final uri = Uri.parse('https://verifiseu.sharepoint.com/sites/BOK/');
          if (!await launchUrl(uri, mode: LaunchMode.externalApplication) && context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Nie można otworzyć SharePoint.')));
          }
        }, icon: const Icon(Icons.open_in_new), label: const Text('Otwórz SharePoint')),
      ]),
      if (_busy) const LinearProgressIndicator(),
      Padding(padding: const EdgeInsets.symmetric(vertical: 16), child: Text(_notice)),
      Card(child: ListTile(leading: const Icon(Icons.folder_copy_outlined),
        title: Text('Liczba plików: ${_status['file_count'] ?? '—'}'),
        subtitle: Text('Ostatni skan: ${_status['last_scan'] ?? 'brak'}'))),
      const SizedBox(height: 18),
      const Text('Historia zmian', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      if (_changes.isEmpty) const ListTile(title: Text('Brak zmian'), subtitle: Text('Pierwszy skan zapisuje stan początkowy.')),
      for (final change in _changes)
        Card(child: ListTile(
          leading: Icon(switch (change['kind']) {
            'nowy' => Icons.note_add_outlined,
            'usuniety' => Icons.delete_outline,
            _ => Icons.edit_outlined,
          }),
          title: Text('${change['name'] ?? 'Plik'}'),
          subtitle: Text('${change['kind'] ?? ''} · ${change['path'] ?? ''}\n${change['scanned_at'] ?? ''}'),
          isThreeLine: true,
        )),
    ]),
  );
}
