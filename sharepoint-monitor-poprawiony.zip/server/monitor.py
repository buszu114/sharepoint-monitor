"""Minimal authenticated read-only change monitor for a locally synced folder.

Serve behind an HTTPS reverse proxy. No Microsoft 365 authentication bypass.
"""
import hashlib
import hmac
import json
import os
import sqlite3
import threading
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

ROOT = Path(os.environ.get('MONITOR_FOLDER', './watched')).expanduser().resolve()
DB = Path(os.environ.get('MONITOR_DB', './monitor.db')).expanduser().resolve()
API_KEY = os.environ.get('MONITOR_API_KEY', '')
HOST = os.environ.get('MONITOR_HOST', '127.0.0.1')
PORT = int(os.environ.get('MONITOR_PORT', '8765'))
LOCK = threading.Lock()


def connect():
    conn = sqlite3.connect(DB)
    conn.execute('CREATE TABLE IF NOT EXISTS files (path TEXT PRIMARY KEY, fingerprint TEXT NOT NULL)')
    conn.execute('CREATE TABLE IF NOT EXISTS changes (id INTEGER PRIMARY KEY, name TEXT, path TEXT, kind TEXT, scanned_at TEXT)')
    conn.execute('CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT)')
    return conn


def scan():
    if not ROOT.is_dir():
        raise RuntimeError('Katalog monitorowany nie istnieje: ' + str(ROOT))
    with LOCK, connect() as db:
        before = dict(db.execute('SELECT path, fingerprint FROM files'))
        now = {}
        for path in ROOT.rglob('*'):
            if not path.is_file() or path.is_symlink():
                continue
            stat = path.stat()
            relative = path.relative_to(ROOT).as_posix()
            now[relative] = f'{stat.st_size}:{stat.st_mtime_ns}'
        stamp = datetime.now(timezone.utc).isoformat()
        initial = db.execute("SELECT value FROM meta WHERE key='last_scan'").fetchone() is None
        if not initial:
            for path, fingerprint in now.items():
                if path not in before or before[path] != fingerprint:
                    db.execute('INSERT INTO changes(name,path,kind,scanned_at) VALUES(?,?,?,?)',
                               (Path(path).name, path, 'nowy' if path not in before else 'zmieniony', stamp))
            for path in before.keys() - now.keys():
                db.execute('INSERT INTO changes(name,path,kind,scanned_at) VALUES(?,?,?,?)',
                           (Path(path).name, path, 'usuniety', stamp))
        db.execute('DELETE FROM files')
        db.executemany('INSERT INTO files(path,fingerprint) VALUES(?,?)', now.items())
        db.execute("INSERT OR REPLACE INTO meta(key,value) VALUES('last_scan',?)", (stamp,))
        db.execute("INSERT OR REPLACE INTO meta(key,value) VALUES('last_error','')")
        db.commit()
        return {'file_count': len(now), 'last_scan': stamp, 'last_error': ''}


def status():
    with LOCK, connect() as db:
        meta = dict(db.execute('SELECT key,value FROM meta'))
        count = db.execute('SELECT COUNT(*) FROM files').fetchone()[0]
        return {'file_count': count, 'last_scan': meta.get('last_scan'), 'last_error': meta.get('last_error', '')}


def changes():
    with LOCK, connect() as db:
        db.row_factory = sqlite3.Row
        return [dict(row) for row in db.execute('SELECT name,path,kind,scanned_at FROM changes ORDER BY id DESC LIMIT 200')]


class Handler(BaseHTTPRequestHandler):
    def send_json(self, code, data):
        body = json.dumps(data, ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def handle_request(self, post=False):
        if not API_KEY or not hmac.compare_digest(self.headers.get('X-API-Key', ''), API_KEY):
            self.send_json(401, {'error': 'Unauthorized'})
            return
        path = urlsplit(self.path).path
        try:
            if post and path == '/scan':
                self.send_json(200, scan())
            elif not post and path == '/status':
                self.send_json(200, status())
            elif not post and path == '/changes':
                self.send_json(200, changes())
            else:
                self.send_json(404, {'error': 'Not found'})
        except Exception as exc:
            self.send_json(500, {'error': str(exc)})

    def do_GET(self):
        self.handle_request()

    def do_POST(self):
        self.handle_request(post=True)


if __name__ == '__main__':
    if len(API_KEY) < 24:
        raise SystemExit('MONITOR_API_KEY must contain at least 24 characters')
    print(f'Monitoring {ROOT}; serving http://{HOST}:{PORT} (use HTTPS reverse proxy)')
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
