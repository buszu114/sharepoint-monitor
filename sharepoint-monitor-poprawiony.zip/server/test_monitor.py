"""Regression tests for file monitoring; uses only temporary data."""
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import monitor


class MonitorTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        base = Path(self.tmp.name)
        self.root = base / 'watched'
        self.root.mkdir()
        self.db = base / 'monitor.db'
        self.root_patch = patch.object(monitor, 'ROOT', self.root)
        self.db_patch = patch.object(monitor, 'DB', self.db)
        self.root_patch.start()
        self.db_patch.start()
        self.addCleanup(self.root_patch.stop)
        self.addCleanup(self.db_patch.stop)

    def test_initial_scan_and_changes(self):
        file = self.root / 'example.txt'
        file.write_text('first', encoding='utf-8')
        self.assertEqual(monitor.scan()['file_count'], 1)
        self.assertEqual(monitor.changes(), [])
        file.write_text('updated content', encoding='utf-8')
        monitor.scan()
        self.assertEqual(monitor.changes()[0]['kind'], 'zmieniony')
        (self.root / 'new.txt').write_text('new', encoding='utf-8')
        monitor.scan()
        self.assertEqual(monitor.changes()[0]['kind'], 'nowy')
        file.unlink()
        monitor.scan()
        self.assertEqual(monitor.changes()[0]['kind'], 'usuniety')
        self.assertEqual(monitor.status()['file_count'], 1)

    def test_missing_folder_does_not_modify_database(self):
        monitor.scan()
        self.root.rmdir()
        with self.assertRaises(RuntimeError):
            monitor.scan()
        self.assertEqual(monitor.status()['file_count'], 0)


if __name__ == '__main__':
    unittest.main()
