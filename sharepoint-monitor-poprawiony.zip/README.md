# SharePoint Monitor — nowa wersja

Aplikacja Android (Flutter) i prosty serwer monitorujący **lokalnie zsynchronizowany, legalnie dostępny katalog**.

## Co robi

- Android: zapisuje URL serwera i klucz API w bezpiecznym magazynie systemowym, pobiera stan i historię zmian, wywołuje skan ręczny, otwiera SharePoint w przeglądarce.
- Serwer: porównuje ścieżki, rozmiary i czasy modyfikacji plików, zapisuje historię SQLite; pierwszy skan tworzy punkt odniesienia.
- GitHub Actions: generuje projekt Android, pobiera pakiety, wykonuje analizę i testy, buduje debug APK i udostępnia artefakt.

## Ważne ograniczenia

To **nie jest** klient omijający logowanie do Microsoft 365. Dostęp do firmowych plików wymaga uprawnień. Serwer nie pobiera samodzielnie dokumentów z SharePoint — trzeba wskazać folder już zsynchronizowany z uprawnionego konta lub przygotować autoryzowaną integrację Microsoft Graph. Serwer musi działać, aby telefon otrzymywał aktualizacje. Skanowanie jest ręczne; aby działało cyklicznie, skonfiguruj harmonogram po stronie serwera. Nie umieszczaj kluczy ani plików firmowych w publicznym repozytorium.

## Budowa APK na GitHub

1. Wgraj **rozpakowane** pliki z tego archiwum do repozytorium (foldery `mobile`, `server`, `.github` i pliki w katalogu głównym). Nie wgrywaj samego ZIP.
2. Wejdź w `Actions > Zbuduj APK Android` i wybierz najnowszy przebieg lub `Run workflow`.
3. Po sukcesie pobierz `sharepoint-monitor-debug-apk` w sekcji Artifacts. Rozpakuj i zainstaluj `app-debug.apk` na Androidzie.

APK jest wersją **debug do testów**, a nie podpisanym wydaniem produkcyjnym.

## Serwer (Linux, Python 3.9+)

```bash
mkdir -p ~/monitor-files
export MONITOR_FOLDER="$HOME/monitor-files"
export MONITOR_DB="$HOME/monitor.db"
export MONITOR_API_KEY="TU_WSTAW_DLUGI_LOSOWY_TAJNY_KLUCZ_MIN_24_ZNAKI"
python3 server/monitor.py
```

Domyślnie serwer nasłuchuje tylko na `127.0.0.1:8765` po HTTP. Aby połączyć telefon, wystaw go **za poprawnie skonfigurowanym HTTPS reverse proxy** z kontrolą dostępu; nie otwieraj go bezpośrednio do Internetu. W aplikacji wpisz adres HTTPS i ten sam klucz API. W przypadku firmowego SharePoint upewnij się, że synchronizacja i dostęp są zgodne z zasadami organizacji.

## Kontrola jakości

W GitHub Actions: `flutter analyze`, `flutter test`, `flutter build apk --debug`.

Lokalnie można uruchomić `python3 -m py_compile server/monitor.py` i `flutter analyze` (po zainstalowaniu Flutter SDK). Bez uruchomienia GitHub Actions nie można potwierdzić gotowego APK.
